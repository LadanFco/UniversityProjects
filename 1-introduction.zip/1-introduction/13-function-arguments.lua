function f(a, b)
    return a and b
end

print(f(3))
print(f(3, 4))
print(f(3, 4, 5))
