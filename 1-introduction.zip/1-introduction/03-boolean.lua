print(true)
print(true and false)
print(true and (false or true))
print(false or (true and false) or (true and true))
