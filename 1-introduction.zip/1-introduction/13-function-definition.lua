function add(a, b)
    return a + b 
end

print(add(2, 3))

add = function(a, b)
    return a + b 
end 

print(add(2, 3))
