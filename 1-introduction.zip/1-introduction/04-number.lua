A = 6 + 2.2 * 4e+3
a = A ^ 2
b = A % 7
print(a)
print(b)
print(a > b)
print(b ~= 2)
