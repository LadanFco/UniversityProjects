print(8*9, 9/8)

a = math.sin(3) + math.cos(10)
print(a)

print(os.time())
print(string.find("pattern", "tt"))
