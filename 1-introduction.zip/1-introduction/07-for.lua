for i = 1, 10 do
	print(i)
end

for i = 1, 10, 2 do
	print(i)
end
