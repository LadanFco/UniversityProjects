a = 1
b = a*2
a = 1; b = a*2
a = 1 b = a*2

print(a)
print(b)

