print("hello")
print('hello')
x = 2
print ("x = "..x)
