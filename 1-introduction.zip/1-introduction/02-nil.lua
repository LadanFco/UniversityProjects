print(c)
c = 10
print(type(c)) 
c = nil
print(type(c))
print(type("a string!!"))
print(type(print))
